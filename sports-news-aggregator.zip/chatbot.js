// DOM Elements
const chatbotButton = document.getElementById("chatbot-button")
const chatbotBox = document.getElementById("chatbot-box")
const closeButton = document.getElementById("close-chatbot")
const messagesContainer = document.getElementById("chatbot-messages")
const userInput = document.getElementById("user-input")
const sendButton = document.getElementById("send-message")

// Gemini API Key
// In a production environment, this should be secured on the server side
const GEMINI_API_KEY = "YOUR_GEMINI_API_KEY" // Replace with your actual API key

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  // Toggle chatbot visibility
  chatbotButton.addEventListener("click", toggleChatbot)
  closeButton.addEventListener("click", toggleChatbot)

  // Send message on button click
  sendButton.addEventListener("click", sendMessage)

  // Send message on Enter key
  userInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      sendMessage()
    }
  })
})

// Functions
function toggleChatbot() {
  const isVisible = chatbotBox.style.display === "flex"
  chatbotBox.style.display = isVisible ? "none" : "flex"

  if (!isVisible) {
    userInput.focus()
  }
}

function sendMessage() {
  const message = userInput.value.trim()

  if (message === "") return

  // Add user message to chat
  addMessage(message, "user")

  // Clear input
  userInput.value = ""

  // Show typing indicator
  showTypingIndicator()

  // Process with Gemini AI
  processWithGemini(message)
}

function addMessage(text, sender) {
  const messageElement = document.createElement("div")
  messageElement.className = `message ${sender}-message`
  messageElement.innerHTML = `<p>${text}</p>`
  messagesContainer.appendChild(messageElement)

  // Scroll to bottom
  messagesContainer.scrollTop = messagesContainer.scrollHeight
}

function showTypingIndicator() {
  const typingIndicator = document.createElement("div")
  typingIndicator.className = "typing-indicator"
  typingIndicator.id = "typing-indicator"
  typingIndicator.innerHTML = `
    <span></span>
    <span></span>
    <span></span>
  `
  messagesContainer.appendChild(typingIndicator)
  messagesContainer.scrollTop = messagesContainer.scrollHeight
}

function removeTypingIndicator() {
  const typingIndicator = document.getElementById("typing-indicator")
  if (typingIndicator) {
    typingIndicator.remove()
  }
}

// For demo purposes, we'll simulate the Gemini API response
// In a real application, you would make an actual API call to Gemini
async function processWithGemini(message) {
  try {
    // In a real app, you would use:
    // const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'Authorization': `Bearer ${GEMINI_API_KEY}`
    //   },
    //   body: JSON.stringify({
    //     contents: [
    //       {
    //         parts: [
    //           {
    //             text: `You are a helpful sports assistant. Answer the following sports-related question: ${message}`
    //           }
    //         ]
    //       }
    //     ]
    //   })
    // });
    // const data = await response.json();
    // const botResponse = data.candidates[0].content.parts[0].text;

    // For demo purposes, we'll simulate an API call with a timeout
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Remove typing indicator
    removeTypingIndicator()

    // Get mock response based on user query
    const botResponse = getMockGeminiResponse(message)

    // Add bot response to chat
    addMessage(botResponse, "bot")
  } catch (error) {
    console.error("Error processing with Gemini:", error)
    removeTypingIndicator()
    addMessage("I'm sorry, I couldn't process your request. Please try again later.", "bot")
  }
}

// Mock responses for demo purposes
function getMockGeminiResponse(message) {
  const lowerMessage = message.toLowerCase()

  if (lowerMessage.includes("world cup") || lowerMessage.includes("fifa")) {
    return "The last FIFA World Cup was held in 2022 in Qatar, and Argentina won the tournament by defeating France in the final on penalties after a thrilling 3-3 draw. Lionel Messi was named the tournament's best player."
  }

  if (lowerMessage.includes("nba") || lowerMessage.includes("basketball")) {
    return "The NBA is currently in the playoff season. The Boston Celtics and Minnesota Timberwolves have been performing exceptionally well. Last season, the Denver Nuggets won the NBA Championship by defeating the Miami Heat in the finals, with Nikola Jokić winning the Finals MVP award."
  }

  if (lowerMessage.includes("tennis") || lowerMessage.includes("grand slam")) {
    return "In tennis, there are four Grand Slam tournaments: the Australian Open, French Open (Roland Garros), Wimbledon, and the US Open. Novak Djokovic currently holds the record for most Grand Slam titles in men's singles with 24 championships."
  }

  if (lowerMessage.includes("cricket") || lowerMessage.includes("ipl")) {
    return "Cricket is played in various formats including Test matches, One Day Internationals (ODIs), and Twenty20 (T20). The ICC Cricket World Cup is held every four years, with the most recent one won by Australia in 2023. The Indian Premier League (IPL) is the most popular T20 cricket league in the world."
  }

  if (lowerMessage.includes("formula") || lowerMessage.includes("f1")) {
    return "Formula 1 is the highest class of international racing for single-seater formula racing cars. Max Verstappen of Red Bull Racing is the current World Champion, having won the 2021, 2022, and 2023 championships. Lewis Hamilton holds the joint record for most World Championships (7) alongside Michael Schumacher."
  }

  if (lowerMessage.includes("football") || lowerMessage.includes("soccer")) {
    return "Football (soccer) is the world's most popular sport. The UEFA Champions League is the most prestigious club competition, while the FIFA World Cup is the premier international tournament. Lionel Messi and Cristiano Ronaldo are considered two of the greatest players of all time."
  }

  if (lowerMessage.includes("hello") || lowerMessage.includes("hi") || lowerMessage.includes("hey")) {
    return "Hello! I'm your sports assistant powered by Gemini AI. How can I help you with sports information today?"
  }

  if (lowerMessage.includes("thank")) {
    return "You're welcome! If you have any more questions about sports, feel free to ask."
  }

  // Default response
  return "I'm your sports assistant. I can provide information about various sports including football, basketball, tennis, cricket, and Formula 1. What would you like to know?"
}
