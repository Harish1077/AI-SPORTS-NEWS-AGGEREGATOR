// DOM Elements
const hamburger = document.querySelector(".hamburger")
const navLinks = document.querySelector(".nav-links")
const filterButtons = document.querySelectorAll(".filter-btn")
const newsContainer = document.getElementById("news-container")
const errorContainer = document.getElementById("error-container")
const retryBtn = document.getElementById("retry-btn")

// API Configuration
// Using NewsAPI for sports news
// Note: In a production environment, you would handle API requests server-side
// to protect your API key
const NEWS_API_KEY = "YOUR_NEWS_API_KEY" // Replace with your actual API key
const NEWS_API_URL = "https://newsapi.org/v2/top-headlines"

// State
let currentCategory = "all"
let newsData = []

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  // Initialize the app
  fetchNews(currentCategory)

  // Mobile menu toggle
  hamburger.addEventListener("click", toggleMobileMenu)

  // Filter buttons
  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const category = button.dataset.category
      setActiveCategory(category)
      filterNews(category)
    })
  })

  // Retry button
  retryBtn.addEventListener("click", () => {
    errorContainer.style.display = "none"
    fetchNews(currentCategory)
  })
})

// Functions
function toggleMobileMenu() {
  navLinks.classList.toggle("active")
  const spans = hamburger.querySelectorAll("span")
  spans[0].classList.toggle("rotate-45")
  spans[1].classList.toggle("opacity-0")
  spans[2].classList.toggle("rotate-negative-45")
}

function setActiveCategory(category) {
  currentCategory = category
  filterButtons.forEach((button) => {
    if (button.dataset.category === category) {
      button.classList.add("active")
    } else {
      button.classList.remove("active")
    }
  })
}

// For demo purposes, we'll use mock data instead of actual API calls
// In a real application, you would use the actual NewsAPI
async function fetchNews(category) {
  try {
    // Show skeleton loaders
    displaySkeletonLoaders()

    // In a real app, you would use:
    // const url = `${NEWS_API_URL}?country=us&category=sports&apiKey=${NEWS_API_KEY}`;
    // const response = await fetch(url);
    // const data = await response.json();

    // For demo purposes, we'll simulate an API call with a timeout
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Mock data
    const data = getMockNewsData()

    // Process and display news
    newsData = data.articles
    displayNews(newsData)
  } catch (error) {
    console.error("Error fetching news:", error)
    showError()
  }
}

function filterNews(category) {
  displaySkeletonLoaders()

  setTimeout(() => {
    let filteredNews

    if (category === "all") {
      filteredNews = newsData
    } else {
      filteredNews = newsData.filter((news) => {
        // Simple filtering based on title or description containing the category name
        const content = (news.title + news.description).toLowerCase()
        return content.includes(category.toLowerCase())
      })
    }

    displayNews(filteredNews)
  }, 800) // Add a small delay for better UX
}

function displayNews(news) {
  // Clear the container
  newsContainer.innerHTML = ""

  if (news.length === 0) {
    newsContainer.innerHTML = `
      <div class="no-news">
        <p>No news found for this category. Please try another category.</p>
      </div>
    `
    return
  }

  // Create news cards
  news.forEach((article) => {
    const newsCard = document.createElement("div")
    newsCard.className = "news-card"

    // Format date
    const publishedDate = new Date(article.publishedAt)
    const formattedDate = publishedDate.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })

    // Determine category based on content
    let category = "General"
    const content = (article.title + article.description).toLowerCase()

    if (content.includes("football") || content.includes("soccer")) {
      category = "Football"
    } else if (content.includes("basketball") || content.includes("nba")) {
      category = "Basketball"
    } else if (content.includes("tennis")) {
      category = "Tennis"
    } else if (content.includes("cricket")) {
      category = "Cricket"
    } else if (content.includes("formula") || content.includes("f1")) {
      category = "Formula 1"
    }

    newsCard.innerHTML = `
      <div class="news-img">
        <img src="${article.urlToImage || "https://placehold.co/600x400/e0e0e0/818181?text=No+Image"}" alt="${article.title}">
      </div>
      <div class="news-content">
        <span class="news-category">${category}</span>
        <h3 class="news-title">${article.title}</h3>
        <p class="news-description">${article.description || "No description available"}</p>
        <div class="news-meta">
          <span class="news-source">${article.source.name}</span>
          <span class="news-date">${formattedDate}</span>
        </div>
      </div>
    `

    // Add click event to open the full article
    newsCard.addEventListener("click", () => {
      window.open(article.url, "_blank")
    })

    newsContainer.appendChild(newsCard)
  })
}

function displaySkeletonLoaders() {
  newsContainer.innerHTML = ""

  for (let i = 0; i < 6; i++) {
    const skeletonCard = document.createElement("div")
    skeletonCard.className = "news-card skeleton"
    skeletonCard.innerHTML = `
      <div class="news-img skeleton-img"></div>
      <div class="news-content">
        <div class="skeleton-title"></div>
        <div class="skeleton-text"></div>
        <div class="skeleton-text"></div>
        <div class="skeleton-text"></div>
      </div>
    `
    newsContainer.appendChild(skeletonCard)
  }
}

function showError() {
  newsContainer.style.display = "none"
  errorContainer.style.display = "block"
}

// Mock data for demo purposes
function getMockNewsData() {
  return {
    status: "ok",
    totalResults: 10,
    articles: [
      {
        source: {
          id: "espn",
          name: "ESPN",
        },
        author: "ESPN Staff",
        title: "Manchester United secures dramatic win against Liverpool in Premier League clash",
        description:
          "In a thrilling match at Old Trafford, Manchester United came from behind to defeat Liverpool 3-2 with a last-minute goal from Bruno Fernandes.",
        url: "https://example.com/news/1",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Football+News",
        publishedAt: "2024-04-26T15:30:00Z",
        content:
          "Manchester United secured a dramatic 3-2 victory against Liverpool at Old Trafford on Sunday, with Bruno Fernandes scoring a stunning free-kick in the final minute of stoppage time.",
      },
      {
        source: {
          id: "nba",
          name: "NBA.com",
        },
        author: "NBA Staff",
        title: "Lakers advance to NBA Western Conference Finals after Game 7 thriller",
        description:
          "LeBron James led the Los Angeles Lakers to a decisive Game 7 victory against the Denver Nuggets, securing their spot in the Western Conference Finals.",
        url: "https://example.com/news/2",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Basketball+News",
        publishedAt: "2024-04-25T12:15:00Z",
        content:
          "The Los Angeles Lakers have advanced to the NBA Western Conference Finals after a thrilling Game 7 victory over the Denver Nuggets. LeBron James recorded a triple-double with 35 points, 12 rebounds, and 10 assists.",
      },
      {
        source: {
          id: "tennis",
          name: "Tennis.com",
        },
        author: "Tennis Reporter",
        title: "Novak Djokovic claims record-extending Grand Slam title at Roland Garros",
        description:
          "Novak Djokovic defeated Carlos Alcaraz in a five-set thriller to win his 24th Grand Slam title at the French Open.",
        url: "https://example.com/news/3",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Tennis+News",
        publishedAt: "2024-04-24T09:45:00Z",
        content:
          "Novak Djokovic has claimed his 24th Grand Slam title after defeating Carlos Alcaraz in a thrilling five-set match at Roland Garros. The Serbian star came back from two sets down to secure the victory.",
      },
      {
        source: {
          id: "cricket",
          name: "CricInfo",
        },
        author: "Cricket Reporter",
        title: "India dominates England in first Test match of the series",
        description:
          "India took a 1-0 lead in the five-match Test series against England with a comprehensive victory in the opening Test at Lord's.",
        url: "https://example.com/news/4",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Cricket+News",
        publishedAt: "2024-04-23T14:20:00Z",
        content:
          "India has taken a 1-0 lead in the five-match Test series against England with a comprehensive victory in the opening Test at Lord's. Virat Kohli scored a century in the first innings, while Jasprit Bumrah took a five-wicket haul in the second innings.",
      },
      {
        source: {
          id: "f1",
          name: "Formula1.com",
        },
        author: "F1 Reporter",
        title: "Max Verstappen wins Monaco Grand Prix to extend championship lead",
        description:
          "Red Bull's Max Verstappen secured a dominant victory at the Monaco Grand Prix, extending his lead in the Formula 1 World Championship.",
        url: "https://example.com/news/5",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Formula+1+News",
        publishedAt: "2024-04-22T16:10:00Z",
        content:
          "Max Verstappen has extended his lead in the Formula 1 World Championship with a dominant victory at the Monaco Grand Prix. The Red Bull driver started from pole position and led every lap of the race.",
      },
      {
        source: {
          id: "football",
          name: "Goal.com",
        },
        author: "Football Reporter",
        title: "Real Madrid clinches La Liga title with three games to spare",
        description:
          "Real Madrid secured their 36th La Liga title after a convincing 4-0 victory against Barcelona in El Clasico.",
        url: "https://example.com/news/6",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Football+News",
        publishedAt: "2024-04-21T18:30:00Z",
        content:
          "Real Madrid has clinched their 36th La Liga title with three games to spare after a convincing 4-0 victory against Barcelona in El Clasico. Vinicius Junior scored a hat-trick, while Jude Bellingham added another goal.",
      },
      {
        source: {
          id: "basketball",
          name: "ESPN",
        },
        author: "Basketball Reporter",
        title: "Boston Celtics sweep Brooklyn Nets to advance in NBA Playoffs",
        description:
          "The Boston Celtics completed a 4-0 sweep of the Brooklyn Nets to advance to the Eastern Conference Semifinals in the NBA Playoffs.",
        url: "https://example.com/news/7",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Basketball+News",
        publishedAt: "2024-04-20T21:45:00Z",
        content:
          "The Boston Celtics have advanced to the Eastern Conference Semifinals after completing a 4-0 sweep of the Brooklyn Nets in the first round of the NBA Playoffs. Jayson Tatum led the way with 29 points in the series-clinching victory.",
      },
      {
        source: {
          id: "tennis",
          name: "ATP Tour",
        },
        author: "Tennis Writer",
        title: "Rafael Nadal announces retirement from professional tennis",
        description:
          "Tennis legend Rafael Nadal has announced his retirement from professional tennis after a career spanning over two decades.",
        url: "https://example.com/news/8",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Tennis+News",
        publishedAt: "2024-04-19T11:05:00Z",
        content:
          "Tennis legend Rafael Nadal has announced his retirement from professional tennis after a career spanning over two decades. The 22-time Grand Slam champion will play his final tournament at the Davis Cup Finals in November.",
      },
      {
        source: {
          id: "cricket",
          name: "ICC",
        },
        author: "Cricket Writer",
        title: "Australia wins T20 World Cup in thrilling final against India",
        description:
          "Australia claimed their second T20 World Cup title after defeating India in a nail-biting final that went down to the last ball.",
        url: "https://example.com/news/9",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Cricket+News",
        publishedAt: "2024-04-18T13:25:00Z",
        content:
          "Australia has claimed their second T20 World Cup title after defeating India in a nail-biting final that went down to the last ball. Pat Cummins held his nerve in the final over to defend 10 runs and secure the victory for Australia.",
      },
      {
        source: {
          id: "f1",
          name: "Sky Sports",
        },
        author: "F1 Writer",
        title: "Lewis Hamilton announces shock move to Ferrari for 2025 season",
        description:
          "Seven-time Formula 1 World Champion Lewis Hamilton will leave Mercedes at the end of the 2024 season to join Ferrari on a multi-year deal.",
        url: "https://example.com/news/10",
        urlToImage: "https://placehold.co/600x400/e0e0e0/818181?text=Formula+1+News",
        publishedAt: "2024-04-17T10:40:00Z",
        content:
          "Seven-time Formula 1 World Champion Lewis Hamilton will leave Mercedes at the end of the 2024 season to join Ferrari on a multi-year deal. The British driver has been with Mercedes since 2013 and has won six of his seven world titles with the team.",
      },
    ],
  }
}
